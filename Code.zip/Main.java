package projet_fromont_jallade;

import java.io.IOException;
import java.util.Scanner;

public class Main {

	public static void main(String[] args) {
		
		boolean premier_jeu = true;
		while(true) {
			
			@SuppressWarnings("resource")
			Scanner sc = new Scanner(System.in);
			if (premier_jeu) {System.out.println("A quel jeu voulez-vous jouer?\n1: Domino\n2: Domino Gommettes\n3: Saboteur\n4: Puzzle");
			premier_jeu = false;}
			else {System.out.println("Voulez-vous jouer à un autre jeu?\n1: Domino\n2: Domino Gommettes\n3: Saboteur\n4: Puzzle");}
			int jeu  = sc.nextInt();
			while(jeu <= 0 || jeu > 4) {
				System.out.println("Rentrez un numero valide");
				jeu = sc.nextInt();
			}
			
			switch(jeu) {
				case 1:	new Domino(1);
				case 2: new DominoGommette(1);
				case 3:
						try {
							System.out.println("je print saboteur");
							new Saboteur(3);
						}catch (WrongCardException e) {}
				case 4:
					char rep = ' ';
					System.out.println("Voulez-vous jouer avec l'interface graphique ou avec la representation textuelle? I/T");
					rep = sc.next().charAt(0);
						if (rep == 'T') {
							try {
								new Puzzle("PuzzleChat","C:\\Users\\Leo-PC\\Documents\\Projets\\Image_java",false);
							} catch (IOException e) {
								System.out.println("Le fichier contenant les images n'a pas été trouvé");}
						
						}else if (rep == 'I')
							try {
								Puzzle modeleP = new Puzzle("PuzzleChat","C:\\Users\\Leo-PC\\Documents\\Projets\\Image_java",true);
								VueGenerale vg = new VueGenerale(modeleP);
								}
						 catch (IOException e) {
							System.out.println("Le fichier contenant les images n'a pas été trouvé");
							}
					}
			}
	}
}