package projet_fromont_jallade;

import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.util.LinkedList;
import java.util.Random;
import java.util.Scanner;

import javax.imageio.ImageIO;

public class Puzzle extends Jeu<PiecePuzzle> implements DeroulementGeneral{
	
	private Random r;
	private Scanner sc;
	@SuppressWarnings("rawtypes")
	private Joueur j;
	private Plateau grille;
	private String nomPuzzle;
	private BufferedImage puzzle_complet;
	private PiecePuzzle p_choisie;
	private PiecePuzzle p_correcte;
	
	//partie interface
	private VueGenerale vueG;
	private boolean interf;

	@SuppressWarnings({"unchecked" })
	public Puzzle(String nomPuzzle, String dossier,boolean interf) throws IOException {
		
		this.interf = interf;
		this.nomPuzzle = nomPuzzle;
		setNom("Puzzle");
		setNb_pieces(16);
		this.puzzle_complet = ImageIO.read(new File(dossier + "/PuzzleChatComplet.jpg"));

		this.createPlayer();
		
		setPlateau(new Plateau(new Case[getNb_pieces()])); //plateau du joueur
		grille = new Plateau(new Case[getNb_pieces()]); //fait ref au plateau de base que l'on va comparer avec plato du joueur
		
		this.createPieces(dossier);
		remplirgrille();
		
		j.setJeuJ(shuffle(PiecePuzzle.getPioche()));//creer la main du joueur avec toutes les pieces;

		if(!(interf)) {
			j.afficheJeuJ();
			this.jeu();
		}
	}
	
	@Override
	@SuppressWarnings("rawtypes")
	public void createPlayer() {
		setSc(new Scanner(System.in));
		System.out.println("Entrez votre nom");
		String name = getSc().nextLine();
		j = new Joueur(name); 
		
	}


	@SuppressWarnings("rawtypes")
	public boolean poserPiece(Joueur j,PiecePuzzle Pgrille,PiecePuzzle Pjoueur, Plateau p){
		if(j.sac_pieces.contains(Pjoueur)) {
			if(Pjoueur.getPosition() == Pgrille.getPosition()) {
				p.placePiece(Pjoueur, Pjoueur.getPosition()-1);
				if (!interf) {System.out.println("*-Vous placez votre piece-*");}
				j.getJeuJ().remove(Pjoueur);
				return true;
			}
			else {
				if (!interf) {System.out.println("*-Cette piece ne va pas ici...-*");}
				return false;
			}
		
		}else	
			return false;
	}
	
	
	
	public LinkedList<PiecePuzzle> shuffle(LinkedList<PiecePuzzle> mainNonMel) {
		int taille = mainNonMel.size();
		r = new Random();
		LinkedList<PiecePuzzle> mainMel = new LinkedList<PiecePuzzle>();
		for(int i=0;i<taille;i++){
			int alea = r.nextInt(mainNonMel.size());
			mainMel.add(mainNonMel.get(alea));
			mainNonMel.remove(mainNonMel.get(alea));
		}
		return mainMel;
	}
	
	public void createPieces(String dossier) throws IOException{
		for(int i=0; i<getNb_pieces();i++) {
			new PiecePuzzle(dossier,this.nomPuzzle,i+1); 
		}
	}
	
	public void remplirgrille() {
		for(int i=0;i<grille.getPlateau().length;i++) {
			for(PiecePuzzle pp : PiecePuzzle.getPioche()) {
				if(pp.getPosition() == i+1) {
					//met la piecepuzzle de position x correspondant e la position i du tableau grille
					grille.placePiece(pp, i);
				}
			}
		}
	}
	
	@Override
	public void jeu() {
			System.out.println("Voici votre Puzzle a remplir... Bon courage !");
			getPlateau().affichePlateauPuzzle();
			Long tempsD = System.currentTimeMillis();
			boolean end = false;
			while(!(end)) {
				p_choisie = null;
				p_correcte = null;
				do {
					int posMain = 0;
					System.out.println("Choisissez une piece de votre jeu (Sa place dans votre main)");
					do{
						sc = new Scanner(System.in);
						System.out.println("Saisissez la position");
						posMain = sc.nextInt();
					}while(posMain > j.getJeuJ().size() || posMain<1);
					
					p_choisie = (PiecePuzzle) j.getJeuJ().get(posMain-1); //piece du jeu du joueur
					System.out.println("Vous avez choisi la piece :" + p_choisie.toString());
					
					int posPlato = 0;
					System.out.println("Choisissez une place sur la plateau (Case 1 a 16)");
					do{
						sc = new Scanner(System.in);
						System.out.println("Saisissez la position");
						posPlato = sc.nextInt();
					}while(posPlato > getPlateau().getPlateau().length || posPlato<1);
					p_correcte = (PiecePuzzle) grille.getPlateau()[posPlato-1].getPiece(); //donne la piece de la grille correspondant � la place du plateau choisi
					System.out.println("Vous avez choisi la case n:" + posPlato);
				}while(!poserPiece(j, p_correcte, p_choisie, getPlateau()));
				getPlateau().affichePlateauPuzzle();
				end = fin();
			}
			System.out.println("Feliciations Puzzle Complet !");
			Long tempsF = System.currentTimeMillis();
			int sec = (int) ((tempsF-tempsD)/1000)%60;
			int min = (int) ((tempsF-tempsD)/(1000*60))%60;
			int hour = (int) ((tempsF-tempsD)/(1000*60*60))%24;
			System.out.println("Vous avez mis: " + hour + ":" + min +":"+ sec);
	}
	
	@Override
	public boolean fin() {
		if(!(j.MainVide())) {
			j.afficheJeuJ();
			return false;
		}
		return true;
	}
	
	public BufferedImage getImagePuzzle() {return puzzle_complet;}
	public Plateau getGrille() {return grille;}
	
	public void setvu(VueGenerale vg) {this.vueG = vg;}
	
	public VueGenerale getVue() {return vueG;}

	public LinkedList<BufferedImage> getListImgJ() {
		
		LinkedList<BufferedImage> images = new LinkedList<BufferedImage>();
		for (Object pp: j.getJeuJ()) {
			images.add( ((PiecePuzzle)pp).getImagePiece());
		}
		return images;
	}

	@SuppressWarnings("rawtypes")
	public Joueur getJoueur() { return j;}
	
	public void setP_choisie(PiecePuzzle pp) {this.p_choisie = pp;}
	public PiecePuzzle getP_choisie() {return p_choisie;}
	public void setP_correcte(PiecePuzzle pp) {this.p_correcte = pp;}
	public PiecePuzzle getP_correcte() {return p_correcte;}
}
