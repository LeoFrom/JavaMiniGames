package projet_fromont_jallade;

import java.util.LinkedList;
import java.util.Random;

public abstract class Piece {//pas de généricité pcq une Piece ne contient pas d'objets d'autres types

	protected String nom;
	public abstract void setNom(String nom);
	public abstract String getNom();
	
	//Pioche est une classe interne de Piece
	//une Pioche est tjrs liée à classe Piece
	public static class Pioche<T>{ //une pioche pour toutes les pièces
		
		private LinkedList<T> elements;//peut prendre un type générique
		Random r = new Random();
				
		//le type générique en arguement sert à construire la liste
		public Pioche(LinkedList<T> e) {
			
			this.elements = new LinkedList<T>();
			for (T piecesTotales : e) {
				//ajoute moi des elt du mm type que e dans elements
				this.elements.add(piecesTotales);
			}
		}
		
		public void distribution(LinkedList<T> JeuJ, int nb_J) {
			if(nb_J >2) {
				while(JeuJ.size() != 6 ) {
					int i =r.nextInt(elements.size());
					JeuJ.add(elements.get(i));
					elements.remove(elements.get(i));
				}
			}
			else {
				while(JeuJ.size() != 7 ) {
					int i =r.nextInt(elements.size());
					JeuJ.add(elements.get(i));
					elements.remove(elements.get(i));
				}
			}
		}
		
		public void placement_init(Case[] cases) {
			int i =r.nextInt(elements.size());
			cases[0].setPiece((Piece)elements.get(i));
			elements.remove(elements.get(i));
		}
		
		public LinkedList<T> getelements(){
			return elements;
		}
		
		public T getRandElem() {
			int i =r.nextInt(elements.size());
			T Temp = elements.get(i);
			//System.out.println("Vous ne pouvez pas jouer, vous piochez.... " + Temp);
			elements.remove(elements.get(i));
			return Temp;	
		}
		
		public boolean estVide() {
			return (this.elements.size() == 0);
		}
	}
}
