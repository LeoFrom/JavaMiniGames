package projet_fromont_jallade;

public class PieceDominoGommette extends PieceDomino{
	
	private int couleur_droite;
	private int couleur_gauche;
	
	//définir a quel int correspond une couleur et une forme nous memes
	public PieceDominoGommette(int couleur_gauche, int forme_gauche, int couleur_droite, int forme_droite){
		
		super(forme_gauche,forme_droite);
		this.couleur_droite = couleur_droite;
		this.couleur_gauche = couleur_gauche;
		setNom("Piece Domino Gommette");
	}
	
	public int getCouleur_droite() {
		return couleur_droite;
	}

	public int getCouleur_gauche() {
		return couleur_gauche;
	}
	
	public void ChangeCouleurs() {
		int tmp = couleur_gauche;
		couleur_gauche = couleur_droite;
		couleur_droite = tmp;
	}
	
	
	public String toString() {
		if (direction)
			return "[" +  "F:" + this.valeur_gauche + " C:" + this.couleur_gauche + "|" + "F:" + this.valeur_droite + " C:" +this.couleur_droite + "]" ; //+ this.getNom(); //mettre getnom pour v�rifier si bien une piece domino
		else 
			return "[" + "F:" + this.valeur_gauche +" C:" + this.couleur_gauche + "]"  + "\n" + "[" + "F:" + this.valeur_droite + " C:" +this.couleur_droite + "]" ;//+ this.getNom();
	}

	@Override
	public String getNom() {return this.nom;}
}
