package projet_fromont_jallade;

import java.util.LinkedList;

public class JoueurSaboteur extends Joueur<CarteSaboteur>{

	private final boolean saboteur; //saboteur ou nain -> saboteur = 1 = true
	private LinkedList<Action> cartes_actions;
	
	public JoueurSaboteur(String nom, boolean saboteur) {
		
		super(nom);
		this.saboteur = saboteur;
		cartes_actions = new LinkedList<Action>();
	}
	
	public boolean isSaboteur() {return saboteur;}
	
	public boolean can_use_chemins(){
		
		for (Action a: cartes_actions) {
			if (a.isSabotage()) { return false;}
		}
		return true;
	}
	
	public LinkedList<Action> getcartes_actions(){ return cartes_actions;}
	
	public void afficheCartesActions() {
		for (Action a: cartes_actions) {
			System.out.println(a + " ");
		}
	}
	
	@Override
	public void afficheJoueur() {
		super.afficheJoueur();
		if (!cartes_actions.isEmpty()) {
			System.out.println("**Les cartes actions placees devant vous**");
			afficheCartesActions();
		}
	}
	
	public Action get_carte_jetee(Action carte) {
		for (Action a: cartes_actions) {
			if (a.get_cardvalue() == carte.get_cardvalue() && a.isSabotage() != carte.isSabotage()) {
				return a;
			}
		}
		return null;
	}
}
