package projet_fromont_jallade;

import java.util.LinkedList;

public class PieceDomino extends Piece{ //héritage classique pcq objets qui ne contiennent rien

	protected int valeur_droite;
	protected int valeur_gauche;
	protected boolean direction = true;
	private static LinkedList<PieceDomino> toutes_les_pieces = new LinkedList<PieceDomino>(); //le mettre dans Piece? -> non pcq static pour 1 jeu mais pas pour ts les jeux + type generique doit etre specifié 
	
	//pour creer les pieces vides -> mettre les valeurs à 0 0 
	
	public PieceDomino(int valeur_gauche, int valeur_droite){
		
		setNom("Piece Domino");
		this.valeur_droite = valeur_droite;
		this.valeur_gauche = valeur_gauche;
		toutes_les_pieces.add(this);
	}
	
	public int getValeur_droite() {
		return valeur_droite;
	}

	public void setValeur_droite(int valeur_droite) {
		this.valeur_droite = valeur_droite;
	}

	public int getValeur_gauche() {
		return valeur_gauche;
	}
	
	public boolean getDir() {return direction;}

	public void setValeur_gauche(int valeur_gauche) {
		this.valeur_gauche = valeur_gauche;
	}

	public static LinkedList<PieceDomino> getPioche(){
		return toutes_les_pieces;
	}
	
	public void ChangeDirection() {
		if(direction)
			direction = false;
		direction = true;
	}
	
	public void ChangeValeurs() {
		int tmp = valeur_gauche;
		valeur_gauche = valeur_droite;
		valeur_droite = tmp;
	}
	
	@Override 
	public void setNom(String nom) {this.nom = nom;}
	
	@Override
	public String toString() {
		if (direction)
			return "[" +  this.valeur_gauche + "|" + this.valeur_droite + "]" ; //+ this.getNom(); //mettre getnom pour v�rifier si bien une piece domino
		else 
			return "[" + this.valeur_gauche +  "]"  + "\n" + "[" + this.valeur_droite + "]" ;//+ this.getNom();
	}
	
	@Override
	public String getNom() {return this.nom;}
	
	
}
