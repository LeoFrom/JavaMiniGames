package projet_fromont_jallade;

public class Case{

	private Piece piece;
	
	public Case(Piece piece){this.piece = piece;}

	public void setPiece(Piece p) {this.piece = p;}
	
	public boolean estVide() {return (piece == null);}
	
	public Piece getPiece() {return piece;}
	
	public String toString() {
		if (piece == null){ return "[  ]";}
		return piece.toString();
	}
}
