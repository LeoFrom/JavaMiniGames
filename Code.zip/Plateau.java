package projet_fromont_jallade;

public class Plateau {

	//1 case générale, mais objets différents selon le jeu
	private Case[] cases;
	private int case_precedente;
	
	public Plateau(Case[] cases) {
		
		setCase_precedente(0);
		
		this.cases = cases;//l'instancier avec des cases vides
		//initialise le tableau 
		for (int i=0; i<cases.length;i++) {
				cases[i] = new Case(null);
		}
	}
	
	public void affichePlateau() {
		for (int i=0; i<cases.length;i++) {
			System.out.print(cases[i]);
		}
		System.out.println();
	}
	
	public void affichePlateauPuzzle() {
		for (int i=1; i<cases.length+1;i++) {
			System.out.print(cases[i-1]);
			if(i%4 == 0)  //dans le cas puzzle 16
				System.out.println();
		}
		System.out.println();
	}
	
	public void affichePlateauSab() {
		for (int i=1; i<cases.length+1;i++) {
			System.out.print(i + ": " + cases[i-1] + "\t\t");
			if(i%9 == 0)  //dans le cas sab 45
				System.out.println();
		}
		System.out.println();
	}
	
	public Case[] getPlateau(){
		return cases;
	}

	public int getCase_precedente() {
		return this.case_precedente;
	}

	public void setCase_precedente(int case_precedente) {
		this.case_precedente = case_precedente;
	}
	
	public void placePiece(Piece p,int x) {
		this.cases[x].setPiece(p);
	}
}
