package projet_fromont_jallade;

import java.util.Random;

@SuppressWarnings({ "rawtypes" })
public class DominoGommette extends Domino{
	
	public DominoGommette(int nb_joueur){
		super(nb_joueur);
		setNom("Domino Gommette");
	}
	
	@Override
	public void createPieces(){
		Random r = new Random();
		for(int i=0; i<this.getNb_pieces();i++) {
			int F_gauche = r.nextInt(4)+1;
			int F_droite = r.nextInt(4)+1;
			int C_gauche = r.nextInt(4)+1;
			int C_droite= r.nextInt(4)+1;
			new PieceDominoGommette(C_gauche,F_gauche,C_droite,F_droite);
		}
	}
	
	@Override
	public boolean poserPiece(Joueur j, Piece piece){

		if (j.sac_pieces.contains(piece)){
			PieceDominoGommette precedent = (PieceDominoGommette) getPlateau().getPlateau()[getPlateau().getCase_precedente()].getPiece();
			
			if(getPlateau().getCase_precedente()>28) {
				System.out.println("Il n'a plus aucune piece dans le jeu");
				return false;
			}	
			
			if(precedent.getValeur_droite() == ((PieceDominoGommette) piece).getValeur_gauche()) {
				getPlateau().placePiece(piece, getPlateau().getCase_precedente()+1);
				getPlateau().setCase_precedente(getPlateau().getCase_precedente()+1);
				j.sac_pieces.remove(piece);
			}
			else if(precedent.getValeur_droite() == ((PieceDominoGommette) piece).getValeur_droite()) {
				System.out.println("Vous tournez votre piece");
				((PieceDominoGommette) piece).ChangeValeurs();
				((PieceDominoGommette) piece).ChangeCouleurs();
				getPlateau().placePiece(piece, getPlateau().getCase_precedente()+1);
				getPlateau().setCase_precedente(getPlateau().getCase_precedente()+1);
				j.sac_pieces.remove(piece);
			}
			else if(precedent.getCouleur_droite() == ((PieceDominoGommette) piece).getCouleur_gauche()) { //droite prec et gauche actu 
				getPlateau().placePiece(piece, getPlateau().getCase_precedente()+1);
				getPlateau().setCase_precedente(getPlateau().getCase_precedente()+1);
				j.sac_pieces.remove(piece);
			}
			else if(precedent.getCouleur_droite() == ((PieceDominoGommette) piece).getCouleur_droite()) {
				System.out.println("Vous tournez votre piece");
				((PieceDominoGommette) piece).ChangeValeurs();
				((PieceDominoGommette) piece).ChangeCouleurs();
				getPlateau().placePiece(piece, getPlateau().getCase_precedente()+1);
				getPlateau().setCase_precedente(getPlateau().getCase_precedente()+1);
				j.sac_pieces.remove(piece);
			}
			else
				return false;
		}
		else 
			return false;
		return true;
	}
	
	@Override
	public boolean fin() {
		if (getPioche().estVide()) {
			for (Joueur j : getJoueurs()) {
				for (Object piece : j.getJeuJ()) {
					PieceDominoGommette precedent = (PieceDominoGommette) getPlateau().getPlateau()[getPlateau().getCase_precedente()].getPiece();
					if(precedent.getValeur_droite() != ((PieceDominoGommette) piece).getValeur_droite() && precedent.getValeur_droite() != ((PieceDominoGommette) piece).getValeur_gauche() && precedent.getCouleur_droite() != ((PieceDominoGommette) piece).getCouleur_droite() && precedent.getCouleur_droite() != ((PieceDominoGommette) piece).getCouleur_gauche()) {
						return true;
					}
				}
			}
		}
		return false;
	}
	
	@Override
	public void calculScore() {
		for (Joueur j : getJoueurs()) {
			int scoreJ = 0;
			for (Object piece : j.getJeuJ()) {
				scoreJ += ((PieceDominoGommette) piece).getValeur_droite() + ((PieceDominoGommette) piece).getValeur_gauche() + ((PieceDominoGommette) piece).getCouleur_droite() + ((PieceDominoGommette) piece).getCouleur_gauche() ;
			}
			j.setScoreFin(scoreJ);
		}
	}
}
