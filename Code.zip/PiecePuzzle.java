package projet_fromont_jallade;

import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.util.LinkedList;

import javax.imageio.ImageIO;

public class PiecePuzzle extends Piece{
	
	private BufferedImage image =null;
	private final int position;
	private static LinkedList<PiecePuzzle> toutes_les_pieces = new LinkedList<PiecePuzzle>(); 
	
	public PiecePuzzle(String dossier,String nomPuzzle, int position) throws IOException {
		setNom("Piece Puzzle");
		this.position = position;

		switch (position) {
		case 1: image = ImageIO.read(new File(dossier +  "/" + nomPuzzle + "1.PNG")); //dossier /PuzzleChat1
				break;
		case 2: image = ImageIO.read(new File(dossier +  "/" + nomPuzzle + "2.PNG")); //dossier /PuzzleChat2 etc...
				break;
		case 3: image = ImageIO.read(new File(dossier +  "/" + nomPuzzle + "3.PNG"));
				break;
		case 4: image = ImageIO.read(new File(dossier +  "/" + nomPuzzle + "4.PNG"));
				break;
		case 5: image = ImageIO.read(new File(dossier +  "/" + nomPuzzle + "5.PNG"));
				break;
		case 6: image = ImageIO.read(new File(dossier +  "/" + nomPuzzle + "6.PNG"));
				break;
		case 7: image = ImageIO.read(new File(dossier +  "/" + nomPuzzle + "7.PNG"));
				break;
		case 8: image = ImageIO.read(new File(dossier +  "/" + nomPuzzle + "8.PNG"));
				break;
		case 9: image = ImageIO.read(new File(dossier +  "/" + nomPuzzle + "9.PNG"));
				break;
		case 10: image = ImageIO.read(new File(dossier +  "/" + nomPuzzle + "10.PNG"));
				break;
		case 11: image = ImageIO.read(new File(dossier +  "/" + nomPuzzle + "11.PNG"));
				break;
		case 12: image = ImageIO.read(new File(dossier +  "/" + nomPuzzle + "12.PNG"));
				break;
		case 13: image = ImageIO.read(new File(dossier +  "/" + nomPuzzle + "13.PNG"));
				break;
		case 14: image = ImageIO.read(new File(dossier +  "/" + nomPuzzle + "14.PNG"));
				break;
		case 15: image = ImageIO.read(new File(dossier +  "/" + nomPuzzle + "15.PNG"));
				break;
		case 16: image = ImageIO.read(new File(dossier +  "/" + nomPuzzle + "16.PNG"));
				break;
		}
		toutes_les_pieces.add(this);
	}
	
	
	public int getPosition() {
		return this.position;
	}
	
	public static LinkedList<PiecePuzzle> getPioche(){
		return toutes_les_pieces;
	}
	
	@Override
	public void setNom(String nom) {this.nom = nom; }
	@Override
	public String getNom() {return this.nom; }
	@Override
	public String toString() {return "[" + this.position + "]" ;}
	public BufferedImage getImagePiece() {return image;}
	
}
