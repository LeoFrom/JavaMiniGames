package projet_fromont_jallade;

import java.util.Random;

public class Galerie extends CarteSaboteur{
	//cartes qui peuvent être posées

	private int[] passages = new int[4];
	@SuppressWarnings("unused")
	private final int cardvalue; //nombres de chemins ouverts

	
	public Galerie(int cardvalue) {
		
		setNom("G");
		this.cardvalue = cardvalue;
		this.remplirPassages(cardvalue);
		toutes_les_cartes.add(this);
	}

	@Override
	public void setNom(String nom) {this.nom = nom;}

	@Override
	public String getNom() {return nom; }
	
	@Override
	public String toString() { 
		String rep = getNom()+ ": [";
		for (int i: passages) {
			rep+= i;
		}
		return rep+"]";
	}
	
	
	public int[] getPassages() {return passages;}
	public void setPassages(int[] nouveaux) {passages = nouveaux;}
	
	public void remplirPassages(int nb_chemins) {
		
		Random r = new Random();
		while (nb_chemins!=0) {
			
			int indice = r.nextInt(4);
			
			if (passages[indice] == 0) {
				passages[indice] = 1;
				nb_chemins--;
			}
		}
	}
}