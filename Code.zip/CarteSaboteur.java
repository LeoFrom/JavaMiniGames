package projet_fromont_jallade;

import java.util.LinkedList;

public abstract class CarteSaboteur extends Piece{
	
	protected static LinkedList<CarteSaboteur> toutes_les_cartes = new LinkedList<CarteSaboteur>();
	protected static LinkedList<CarteSaboteur> getPioche() { return toutes_les_cartes;}

}
