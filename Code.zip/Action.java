package projet_fromont_jallade;

public class Action extends CarteSaboteur{
	//cartes qui ne peuvent pas être posées

	private final int cardvalue;
	private final boolean sabotage;

	
	public Action(int cardvalue, boolean sabotage) {
		
		setNom("Carte Action");
		this.cardvalue = cardvalue;
		this.sabotage = sabotage;
		toutes_les_cartes.add(this);	
		
		switch (cardvalue) {
		case 1: if(sabotage) {setNom("Chariot.sab");}
				else{setNom("Chariot.sauv");}
				break;
		case 2: if (sabotage) {setNom("Lampe.sab");}
				else{setNom("Lampe.sauv");}
				break;
		case 3: if (sabotage) {setNom("Outil.sab");}
				else {setNom("Outil.sauv");}
				break;
		}
	}

	@Override
	public void setNom(String nom) {this.nom = nom;}

	@Override
	public String getNom() {return nom; }
	
	@Override
	public String toString() {return getNom();}
	
	public boolean isSabotage() {return sabotage;}
	
	public int get_cardvalue() {return cardvalue;}
}