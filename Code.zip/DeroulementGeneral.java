package projet_fromont_jallade;

public interface DeroulementGeneral {
	//contient toutes les méthodes qui apparaissent dans tous les jeux (a verifier pour puzzle)
	
	//abstract void createPieces();
	abstract <T> void createPlayer();
	abstract void jeu() throws WrongCardException;
	abstract boolean fin();

}
