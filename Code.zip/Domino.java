package projet_fromont_jallade;

import java.util.Scanner;
import java.util.Random;

public class Domino extends Jeu<PieceDomino> implements DeroulementGeneral{
	
	private Random r = new Random();
	
	public Domino(int nb_joueurs){
		
		setNom("Domino");
		setNb_pieces(28);
		setPlateau(new Plateau(new Case[getNb_pieces()]));
		setJoueurs(new Joueur[nb_joueurs]);
		
		
		//---creer les pieces dominos
		this.createPieces();
		
		//---creer la pioche qui contiendra des pieces dominos	
		setPioche(new Piece.Pioche<PieceDomino>(PieceDomino.getPioche()));
		
		//---placer le domino de depart
		getPioche().placement_init(getPlateau().getPlateau());
		
		//---creer les joueurs avec les pieces qu'on a
		this.createPlayer();

		System.out.println("****************Plateau****************");
		getPlateau().affichePlateau();
		System.out.println("***************************************");
		
		//---lancer jeu
		this.jeu();
	}

	@SuppressWarnings({ "unchecked", "rawtypes"})
	public <T> void createPlayer() {
		for (int i=0; i<getJoueurs().length;i++) {
			setSc(new Scanner(System.in));
			System.out.println("Entrez votre nom");
			String name = getSc().nextLine();
			getJoueurs()[i] = new Joueur(name);
			getPioche().distribution(getJoueurs()[i].getJeuJ(),getJoueurs().length);
		}
	}

	public void createPieces(){
		for(int i=0; i<getNb_pieces();i++) {
			int gauche = r.nextInt(7); // de 0 � 6
			int droite = r.nextInt(7); // de 0 � 6
			new PieceDomino(gauche,droite);
		}
		
	}
	
	@Override
	@SuppressWarnings("rawtypes")
	public boolean fin() {
		if (getPioche().estVide()) {
			for (Joueur j : getJoueurs()) {
				for (Object piece : j.getJeuJ()) {
					PieceDomino precedent = (PieceDomino) getPlateau().getPlateau()[getPlateau().getCase_precedente()].getPiece();
					if(precedent.getValeur_droite() != ((PieceDomino) piece).getValeur_droite() && precedent.getValeur_droite() != ((PieceDomino) piece).getValeur_gauche()) {
						return true;
					}
				}
			}
		}
		return false;
	}
	
	@SuppressWarnings("rawtypes")
	public void calculScore() {
		for (Joueur j : getJoueurs()) {
			int scoreJ = 0;
			for (Object piece : j.getJeuJ()) {
				scoreJ += ((PieceDomino) piece).getValeur_droite() + ((PieceDomino) piece).getValeur_gauche();
			}
			j.setScoreFin(scoreJ);
		}
	}
	
	@SuppressWarnings("rawtypes")
	public Joueur JoueurGagnant() {
		calculScore();
		Joueur gagnant = null;
		int ScoreMin = 500;
		for (Joueur j : getJoueurs()) {
			if(j.getScoreFin()<ScoreMin)
				gagnant = j;
		}
		return gagnant;
	}
	
	@SuppressWarnings("rawtypes")
	public boolean poserPiece(Joueur j, Piece piece){

		if (j.sac_pieces.contains(piece)){
			//on recupere la derniere piece placee pour la comparer avec notre piece actuelle
			PieceDomino precedent = (PieceDomino) getPlateau().getPlateau()[getPlateau().getCase_precedente()].getPiece();
			
			if(getPlateau().getCase_precedente()>28) {
				System.out.println("Il n'a plus aucune piece dans le jeu");
				return false;
			}
			
			//on compare la valeur droite de la piece precedente avec la valeur gauche de la piece actuelle
			if(precedent.getValeur_droite() == ((PieceDomino) piece).getValeur_gauche()) {
				getPlateau().placePiece(piece, getPlateau().getCase_precedente()+1);
				getPlateau().setCase_precedente(getPlateau().getCase_precedente()+1);
				j.sac_pieces.remove(piece);
			}
			else if(precedent.getValeur_droite()== ((PieceDomino) piece).getValeur_droite()) {
				System.out.println("Vous tournez votre piece, puis ");
				((PieceDomino) piece).ChangeValeurs();
				getPlateau().placePiece(piece, getPlateau().getCase_precedente()+1);
				getPlateau().setCase_precedente(getPlateau().getCase_precedente()+1);
				j.sac_pieces.remove(piece);
			}
			else
				return false;
		}
		else 
			return false;
		return true;
	}
	
	@SuppressWarnings("rawtypes")
	public void jeu() {
		
		boolean Fin_O_mouvements = false;
		int nb_j = 0;
		while(!(getJoueurs()[nb_j].MainVide())) {
			System.out.println("A votre tour...");
			getJoueurs()[nb_j].afficheJoueur();

			char rep = (Character) ' ';
			int pos = 0;
			while(rep != 'N') {
				System.out.println("Choisissez une piece de votre jeu (Sa place dans votre main)");
				do{
					setSc(new Scanner(System.in));
					System.out.println("Saisissez la position");
					pos = getSc().nextInt();
				}while(pos > getJoueurs()[nb_j].getJeuJ().size() || pos<1);
	
				Piece p_act = (Piece) getJoueurs()[nb_j].getJeuJ().get(pos-1);
				System.out.println("Vous avez choisi la piece :" + p_act.toString());
				
				if(poserPiece(getJoueurs()[nb_j], p_act) == true) {
					System.out.println("Vous placez votre piece....");
					break;
				}
				else {
					System.out.println("Cette piece ne peut etre deposee, voulez vous en choisir une autre ? O/N");
					setSc(new Scanner(System.in));
					rep = getSc().next().charAt(0);
					if(rep == 'N') {
						getJoueurs()[nb_j].JPioche(getPioche());
						break;
					}
				}
			}
			System.out.println("****************Plateau****************");
			getPlateau().affichePlateau();
			System.out.println("***************************************" + "/n");
			//changement de joueurs
			if(nb_j+1>=getJoueurs().length) {
				nb_j = 0;
			}else
				nb_j++;
			
			if(fin()) {
				System.out.println("Plus aucun mouvement possible.. Fin du jeu");
				Fin_O_mouvements = true;
				break;
			}
		}
		if(Fin_O_mouvements) {
			Joueur gg = JoueurGagnant();
			gg.afficheJoueur();
			System.out.print("Feliciations " + gg.getNom() +  " a gagne(e) !" );
		}
			
		else {
			System.out.print("Feliciations " + getJoueurs()[nb_j].getNom() +  " a gagne(e) !" );
		}
	}
}
