package projet_fromont_jallade;

public class But extends Galerie{

	private final boolean pepite; //1 si pépite, 0 si cailloux 

	public But(boolean pepite) {
		
		super(0); //on remplit rien pour l'instant
		setNom("B");
		this.pepite = pepite;
		if (pepite) { //on remplit ici en fonction de la carte
			for (int i = 0; i<getPassages().length; i++) {
				getPassages()[i] = 1;
			}
		}else {
			this.remplirPassages(2);
		}
	}
	
	public boolean isPepite() {return pepite;}
}
