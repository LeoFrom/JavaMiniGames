package projet_fromont_jallade;

import java.util.Scanner;

public abstract class Jeu <T>{
	
	private String nom_jeu;
	private Scanner sc;
	private int nb_pieces;
	@SuppressWarnings("rawtypes")
	private Joueur[] joueurs;
	private Plateau plato;
	private Piece.Pioche<T> pioche;
	
	public String getNom_jeu() {return nom_jeu;}
	public void setNom(String nom_jeu) { this.nom_jeu = nom_jeu;}
	
	public int getNb_pieces() {return nb_pieces;}
	public void setNb_pieces(int nb) {this.nb_pieces = nb;}
	
	public Plateau getPlateau() {return plato;}
	public void setPlateau(Plateau plato) {this.plato = plato;}
	
	@SuppressWarnings("rawtypes")
	public Joueur[] getJoueurs() {return joueurs;}
	@SuppressWarnings("rawtypes")
	public void setJoueurs(Joueur[] joueurs) {this.joueurs = joueurs;}
	
	public void setPioche(Piece.Pioche<T> pioche) {this.pioche = pioche;}
	public Piece.Pioche<T> getPioche() {return pioche;}
	
	public Scanner getSc() {return sc;}
	public void setSc(Scanner sc) {this.sc = sc;}

}
