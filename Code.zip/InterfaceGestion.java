package projet_fromont_jallade;

import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;

public class InterfaceGestion implements ChangeListener{

	private VueGenerale v;
	private Puzzle puzzleM;

	public InterfaceGestion(Puzzle m, VueGenerale v){
		this.v = v;
		this.puzzleM = m;
	}
	
	@Override
	public void stateChanged(ChangeEvent x) {
		
		
	}
}
