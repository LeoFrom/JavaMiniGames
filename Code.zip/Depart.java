package projet_fromont_jallade;

public class Depart extends Galerie{
	
	public Depart(){
		super(4);
		setNom("D");
	}

	@Override
	public void setNom(String nom) {this.nom = nom;}

	@Override
	public String getNom() {return nom;}

}
