package projet_fromont_jallade;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.GridLayout;
import java.util.LinkedList;

import javax.swing.BorderFactory;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JPanel;

public class VueGenerale extends JFrame{
	
	private static final long serialVersionUID = 1L;
	private Puzzle puzzleM;
	private PlateauInterface plateau;
	private MainJoueur main;
	
	@SuppressWarnings("unchecked")
	public VueGenerale(Puzzle puzzleM) {
		this.puzzleM = puzzleM;
		puzzleM.setvu(this);	
		setLayout(new GridLayout(1,2));
		setTitle("Puzzle");
		
		plateau = new PlateauInterface();
		main = new MainJoueur(puzzleM.getJoueur().getJeuJ());
		main.setBackground(new Color(12,81,125));
	
		this.add(plateau);
		this.add(main);
		
	
		pack();
		setVisible(true);
		setPreferredSize(new Dimension(puzzleM.getImagePuzzle().getWidth()*2,puzzleM.getImagePuzzle().getHeight()*2));
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	}
	
	public void setModele(Puzzle m) {
		this.puzzleM = m;
	}
	
	public void miseAJour(Puzzle m, BoutonPuzzle b){
		
		if(puzzleM.poserPiece(puzzleM.getJoueur(), puzzleM.getP_correcte(), puzzleM.getP_choisie(), puzzleM.getPlateau())) {
			//on delvoile l'image de la piece correctement placee
			BoutonPuzzle a_devoiler = plateau.getboutons_grille().get(puzzleM.getP_correcte().getPosition()-1);
			//a_devoiler.setIcon(a_devoiler.getImage());
			a_devoiler.setVisible(false);
			//a_devoiler.setBorder(BorderFactory.createEmptyBorder());
			//a_devoiler.setContentAreaFilled(false);
			//rendre invisible la piece de la pioche qui vient d'etre correctement placee
			b.setVisible(false);
		}
	}
	

	public class MainJoueur extends JPanel{
		
		/**
		 * 
		 */
		private static final long serialVersionUID = 1L;
		private LinkedList<BoutonPuzzle> boutons_jeuJ = new LinkedList<BoutonPuzzle>();
		
		public MainJoueur(LinkedList<PiecePuzzle> MainJ) {
			for (int i=0; i<16; i++) {
				this.setLayout(new GridLayout(5,4));
				BoutonPuzzle button = new BoutonPuzzle(new ImageIcon(MainJ.get(i).getImagePiece()), MainJ.get(i));
				//pour afficher l'image du bonton
				button.setIcon(button.getImage());
				button.setBorder(BorderFactory.createEmptyBorder());
				button.setContentAreaFilled(false);
				boutons_jeuJ.add(button);
				this.add(button);
				this.setVisible(true);
			}
			//ajouter des actions listeners pour les boutons de la pioche
			for (BoutonPuzzle b: boutons_jeuJ) {
				b.addActionListener(e ->{
					//si le bouton est activé, on dit que c'est la piece liée à ce bouton la que le joueur veut placer
					puzzleM.setP_choisie(b.getPiece());
				});
			}
			
			
		}
		public LinkedList<BoutonPuzzle> getboutons_jeu(){return boutons_jeuJ;}
	}
	public class PlateauInterface extends JPanel{
		/**
		 * 
		 */
		private LinkedList<BoutonPuzzle> boutons_grille = new LinkedList<BoutonPuzzle>();
		
		private static final long serialVersionUID = 1L;
		public PlateauInterface(){
			this.setPreferredSize(new Dimension(puzzleM.getImagePuzzle().getWidth(),puzzleM.getImagePuzzle().getHeight()));
			this.setLayout(new GridLayout(4,4));
			Plateau grille = puzzleM.getGrille();
			for(int i=0; i<16 ; i++) {
				BoutonPuzzle bouton = new BoutonPuzzle(new ImageIcon(((PiecePuzzle) grille.getPlateau()[i].getPiece()).getImagePiece()), (PiecePuzzle) grille.getPlateau()[i].getPiece());
	            boutons_grille.add(bouton);
	            this.add(bouton);
	            setVisible(true);
	            
			}
			//ajouter des actions listeners pour les boutons du plateau
			for (BoutonPuzzle b: boutons_grille) {
				b.addActionListener(e ->{
					//dire que c'est la piece liée à ce bouton qu'il faut verifier
					puzzleM.setP_correcte(b.getPiece());
					//et lancer la mise a jour
					for (BoutonPuzzle bp : main.getboutons_jeu()) {
						if ( bp.getPiece() == puzzleM.getP_choisie()) {
							//en donnant le bouton de la pioche qui doit etre supprimé
							puzzleM.getVue().miseAJour(puzzleM, bp);
						}
					}	
				});
			}
		}
		public void paintComponent(Graphics g) {
			super.paintComponent(g);
			g.drawImage(puzzleM.getImagePuzzle(), 0, 0, this);
		}
		
		public LinkedList<BoutonPuzzle> getboutons_grille(){return boutons_grille;}
	}

	public class BoutonPuzzle extends JButton{

	/**
		 * 
		 */
	private static final long serialVersionUID = 1L;
	private ImageIcon image;
	private PiecePuzzle piece;
	
	public BoutonPuzzle(ImageIcon image, PiecePuzzle piece) {
		
		this.image = image; this.piece = piece;
	}
	
	public PiecePuzzle getPiece() {return piece;}
	public ImageIcon getImage() {return image;}
	}	
}
