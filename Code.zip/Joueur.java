package projet_fromont_jallade;

import java.util.LinkedList;

public class Joueur<T> { //joueurs possède des pieces de type T
	
	private final String nom;
	private int scoreFin = 0;
	
	protected LinkedList<T> sac_pieces; //pièces en sa possession, pas final
	
	public Joueur(String nom) {
		this.nom = nom;
		this.sac_pieces = new LinkedList<T>();
	}
	
	@SuppressWarnings({ "rawtypes", "unchecked" })
	public void JPioche(Piece.Pioche p){ //s'applique sur un joueur et prends une pieces al�atoire de la pioche
		if (p.getelements().size() != 0){
			sac_pieces.add((T) p.getRandElem());
		}//exception
		else {
			System.out.println("Il n'y a plus de pieces disponibles");
		}
	}
	
	public String getNom() {
		return nom;
	}

	public  LinkedList<T> getJeuJ(){
		return sac_pieces;
	}
	
	public void setJeuJ(LinkedList<T> jeu_puzzle) {
		this.sac_pieces = jeu_puzzle;
	}
	
	public boolean MainVide() {
		return (sac_pieces.size() == 0);
	}
	
	public void afficheJeuJ() {
		System.out.println("****************Votre main****************");
		for(T pieceJeuJ : sac_pieces) {
			System.out.print(pieceJeuJ + " ");
		}
		System.out.println();
		System.out.println("******************************************");
	}
	public void afficheJoueur() {
		System.out.println("Pseudo: " + nom);
		afficheJeuJ();
		
	}
			
	
	public int getScoreFin() {
		return scoreFin;
	}

	public void setScoreFin(int scoreFin) {
		this.scoreFin = scoreFin;
	}
	
}
