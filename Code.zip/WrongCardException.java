package projet_fromont_jallade;

public class WrongCardException extends Exception{
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	@SuppressWarnings("unused")
	private String bonne_carte;
	@SuppressWarnings("unused")
	private String mauvaise_carte;
	
	public WrongCardException(String bonne_carte, String mauvaise_carte) {
		this.bonne_carte = bonne_carte; this.mauvaise_carte = mauvaise_carte;
		System.out.println("Vous avez choisi une carte " + mauvaise_carte + " au lieu d'une carte " + bonne_carte + " !");
	}

}
