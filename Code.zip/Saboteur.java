package projet_fromont_jallade;

import java.util.LinkedList;
import java.util.Random;
import java.util.Scanner;

public class Saboteur extends Jeu<CarteSaboteur> implements DeroulementGeneral{
	
	private static LinkedList<Integer> chemins = new LinkedList<Integer>();
	
	public Saboteur(int nb_joueurs) throws WrongCardException{
		
		setNom("Saboteur");
		setJoueurs(new Joueur[nb_joueurs]);
		setPlateau(new Plateau(new Case[45]));
		
		//---creer la pioche qui contiendra des cartes saboteurs	
		setPioche(new Piece.Pioche<CarteSaboteur>(new LinkedList<CarteSaboteur>()));
		
		//---creer les cartes saboteurs
		this.createPieces();
		
		//----placer les cartes initiales
		this.placement_init(getPlateau().getPlateau(), (Depart) getPioche().getelements().get(0), 
				new But[] {(But) getPioche().getelements().get(1), (But) getPioche().getelements().get(2), (But) getPioche().getelements().get(3)});
		
		//----creer les joueurs avec les cartes qu'on a
		this.createPlayer();

		//---afficher le plateau
		//plato.affichePlateauSab();
		
		//----lancer le saboteur
		this.jeu();
	}
	
	@SuppressWarnings({"hiding", "unchecked"})
	public <CarteSaboteur> void createPlayer() {
		
		Random r = new Random();
		boolean un_sab = r.nextBoolean();
		for (int i=0; i<getJoueurs().length;i++) {
			setSc(new Scanner(System.in));
			System.out.println("Entrez votre nom joueur " + (i+1));
			String name = getSc().nextLine();

			if(un_sab) {
				getJoueurs()[i] = new JoueurSaboteur(name, false);
			}else {
				getJoueurs()[i] = new JoueurSaboteur(name, true);
				un_sab=true;
			}
			getPioche().distribution(getJoueurs()[i].getJeuJ(), getJoueurs().length);
		}
		System.out.println();
	}
	
	
	public void placement_init(Case[] cases, Depart depart, But[] arrivees) {
		
		cases[10].setPiece(depart);
		chemins.add(10);
		getPioche().getelements().remove(depart);
		cases[8].setPiece(arrivees[0]);
		getPioche().getelements().remove(arrivees[0]);
		cases[26].setPiece(arrivees[1]);
		getPioche().getelements().remove(arrivees[1]);
		cases[44].setPiece(arrivees[2]);
		getPioche().getelements().remove(arrivees[2]);
	}
	
	@Override
	public void jeu(){
		
		System.out.println("*****************Plateau******************");
		getPlateau().affichePlateauSab();
		boolean fin = false;
		int nb_j = 0;
		while(!(fin)) {
			
			System.out.println("A votre tour...");
			getJoueurs()[nb_j].afficheJoueur();

			int pos_carte = 0;
			tour:
			while(true) {
				
				System.out.println("\nChoisissez une piece de votre jeu (Sa place dans votre main)");
				do{
					setSc(new Scanner(System.in));
					System.out.println("Saisissez la position");
					pos_carte = getSc().nextInt();
				}while(pos_carte > getJoueurs()[nb_j].getJeuJ().size() || pos_carte<1);
				
				
				Piece p_act = (Piece) getJoueurs()[nb_j].getJeuJ().get(pos_carte-1);
				System.out.println("Vous avez choisi la carte :" + p_act.toString());
				
				//3 choix a chaque tour
				System.out.println("Voulez vous 1: continuer une route, 2: la jeter, 3: utiliser une action");
				int choix = getSc().nextInt();
				switch(choix) {
				
					case 1:
						if (((JoueurSaboteur)getJoueurs()[nb_j]).can_use_chemins()) {
							try {
								if (p_act instanceof Action) {throw new WrongCardException("Galerie", "Action");}
								System.out.println("Ou voulez vous la placer? Choississez un numero de case sur le plateau");
								int placement = getSc().nextInt();
								
								if(poserPiece(getJoueurs()[nb_j], (Galerie)p_act, placement-1) == true) {
									System.out.println("Vous placez votre carte....");
									break tour;
								}
								else {
									System.out.println("Cette carte ne peut pas etre placee\n");
									break;
								}
							}catch (WrongCardException e) {
								break;
							}
						}else {
							System.out.println("Vous ne pouvez pas deposer de cartes chemins, vous avez ete sabote(e)!");
							break;
						}
					case 2:
						getJoueurs()[nb_j].sac_pieces.remove(p_act);
						break tour;
					case 3:
						try {
							if (p_act instanceof Galerie) {throw new WrongCardException("Action", "Galerie");}
							
							System.out.print("Pour/contre quel joueur voulez-vous l'utiliser? rentrez le numero de joueur\n");
							int joueur = getSc().nextInt();
							
							//si le joueur veut l'utiliser pour lui, on le précise pour la méthode
							if (joueur-1 == nb_j) {utiliser_action((Action)p_act, (JoueurSaboteur)getJoueurs()[joueur-1], true);
							break tour;}
							else { utiliser_action((Action) p_act, (JoueurSaboteur) getJoueurs()[joueur-1], false);
							break tour;}
							
							
						}catch (WrongCardException e) {
							break;
						}
				}
			}
			System.out.println("****************Plateau****************");
			getPlateau().affichePlateauSab();
			System.out.println("***************************************");
			
			//on regarde si les conditions d'arrets de jeu sont remplies
			fin = fin();
			
			//changement de joueurs et on pioche tout le monde a joué son tour
			if(nb_j+1>=getJoueurs().length) {
				nb_j = 0;
				on_pioche();
			}else {
				nb_j++;
			
			}
		}
		System.out.println("Il existe un chemin entre le départ et l'arrivée!");
		System.out.println(getJoueurs()[nb_j].getNom() + " a gagné");
		return;
	}
	
	@Override
	public boolean fin() {
		
		if (getPioche().estVide()) {return true;}
		
		if (chemins.contains(8+9) || chemins.contains(8-1)) {return true;}
		if (chemins.contains(26-9) || chemins.contains(26+9) || chemins.contains(26-1)) {return true;}
		if (chemins.contains(44-9) || chemins.contains(44-1)) {return true;}

		return false;
	}
	

	public void createPieces() {
		
		//rajouter la carte départ et les cartes but
		getPioche().getelements().add(new Depart());
		getPioche().getelements().add(new But(true));
		getPioche().getelements().add(new But(false)); //milieu
		getPioche().getelements().add(new But(false)); //bas à droite

		//rajouter les cartes galeries
		Random r = new Random();
		for (int i=0; i<44; i++) {
			int passages_ouverts = r.nextInt(4)+1;
			getPioche().getelements().add(new Galerie(passages_ouverts));
		}
		
		//rajouter les cartes actions
		int type_action = 1;
		while (type_action < 4) {
			for (int i=0; i<8; i++) {
				if (i%2 ==0) {
					getPioche().getelements().add(new Action(type_action, true));
				}else {
					getPioche().getelements().add(new Action(type_action, false));
				}
			}
			type_action+=1;
		}
	}
	
	public Piece voisin_haut(int pos) {
		
		Piece voisin_haut=null;
		try {
			voisin_haut = getPlateau().getPlateau()[pos-9].getPiece();
		}catch(IndexOutOfBoundsException e){
		}
		return voisin_haut;
	}
	
	public Piece voisin_droite(int pos) {
		
		Piece voisin_droite=null;
		try {
			voisin_droite = getPlateau().getPlateau()[pos+1].getPiece();
		}catch(IndexOutOfBoundsException e){
		}
		return voisin_droite;
	}
	
	public Piece voisin_bas(int pos) {
		
		Piece voisin_bas=null;
		try {
			voisin_bas = getPlateau().getPlateau()[pos+9].getPiece();
		}catch(IndexOutOfBoundsException e){
		}
		return voisin_bas;
	}
	
	public Piece voisin_gauche(int pos) {
		
		Piece voisin_gauche=null;
		try {
			voisin_gauche = getPlateau().getPlateau()[pos-1].getPiece();
		}catch(IndexOutOfBoundsException e){
		}
		return voisin_gauche;
	}
		
	public boolean poserPiece(@SuppressWarnings("rawtypes") Joueur j, Galerie piece, int pos){
	
		if (j.sac_pieces.contains(piece)) {
			
			Galerie v_haut = (Galerie)voisin_haut(pos);
			if (v_haut!= null && chemins.contains(pos-9)) {
				if (v_haut.getPassages()[2] == 1) {
					if(piece.getPassages()[0] == 1){
						getPlateau().placePiece(piece, pos);
						chemins.add(pos);
						j.sac_pieces.remove(piece);
						return true;
					}else if(piece.getPassages()[2] == 1) {
						//changer valeurs
						piece.setPassages(new int[] {piece.getPassages()[2], piece.getPassages()[1], piece.getPassages()[0], piece.getPassages()[3]});
						getPlateau().placePiece(piece, pos);
						chemins.add(pos);
						j.sac_pieces.remove(piece);
						return true;
					}
				}
			}
			Galerie v_droit = (Galerie)voisin_droite(pos);
			if (v_droit!= null && chemins.contains(pos+1)) {
				if (v_droit.getPassages()[3] == 1) {
					if (piece.getPassages()[1] == 1) {
						
						getPlateau().placePiece(piece, pos);
						chemins.add(pos);
						j.sac_pieces.remove(piece);
						return true;
					}else if(piece.getPassages()[3] == 1) {
						//changer valeurs;
						piece.setPassages(new int[] {piece.getPassages()[0], piece.getPassages()[3], piece.getPassages()[2], piece.getPassages()[1]});
						getPlateau().placePiece(piece, pos);
						chemins.add(pos);
						j.sac_pieces.remove(piece);
						return true;
					}
				}
			}
			Galerie v_bas = (Galerie) voisin_bas(pos);
			if (v_bas!= null && chemins.contains(pos+9)) {
				if (v_bas.getPassages()[0] == 1) {
					if (piece.getPassages()[2] == 1) {
						getPlateau().placePiece(piece, pos);
						chemins.add(pos);
						j.sac_pieces.remove(piece);
						return true;
					}else if(piece.getPassages()[0] == 1){
						// changer valeurs
						piece.setPassages(new int[] {piece.getPassages()[2], piece.getPassages()[1], piece.getPassages()[0], piece.getPassages()[3]});
						getPlateau().placePiece(piece, pos);
						chemins.add(pos);
						j.sac_pieces.remove(piece);
					return true;
					}
				}
			}
			Galerie v_gauche = (Galerie) voisin_gauche(pos);
			if (v_gauche!= null && chemins.contains(pos-1)) {
				System.out.println(pos);
				if (v_gauche.getPassages()[1] == 1) {
					if (piece.getPassages()[3] == 1){
						getPlateau().placePiece(piece, pos);
						chemins.add(pos);
						j.sac_pieces.remove(piece);
						return true;
					}else if(piece.getPassages()[1] == 1) {
						//changer valeurs
						piece.setPassages(new int[] {piece.getPassages()[0], piece.getPassages()[3], piece.getPassages()[2], piece.getPassages()[1]});
						getPlateau().placePiece(piece, pos);
						chemins.add(pos);
						j.sac_pieces.remove(piece);
						return true;
					}
				}
			}
		}
		return false;
	}
	
	@SuppressWarnings("rawtypes")
	public void on_pioche() {
		System.out.println("\nTout le monde pioche\n");
		for (Joueur j: getJoueurs()) {
			j.JPioche(getPioche());
		}
	}
	
	public boolean utiliser_action(Action carte, JoueurSaboteur js, boolean b) {
		
		//si le joueur veut utiliser sa carte action sur lui meme
		if (b) {
				// pour s'oter une carte sabotage
				if(!carte.isSabotage()) {
					Action carte_annulee = js.get_carte_jetee(new Action(carte.get_cardvalue(), false));
					if (carte_annulee != null) {					
						js.getcartes_actions().remove(carte_annulee);
						return true;
					}else {
						System.out.println("La carte que vous avez choisie n'annule aucune des cartes actions placees devant vous");
						return false;}
				}else{ System.out.println("Vous n'allez pas vous saboter vous meme!\n"); return false;}
		}
		
		//si le joueur veut saboter/sauver qqn
		else {
			if (js.getcartes_actions().size()<=3) {
				if(!carte.isSabotage()) {
					//remove la carte qui est annulee
					Action carte_annulee = js.get_carte_jetee(new Action(carte.get_cardvalue(), false));
					if (carte_annulee != null) {					
						js.getcartes_actions().remove(carte_annulee);
						return true;
					}else {
						System.out.println("La carte que vous avez choisie n'annule aucune des cartes actions placees devant le joueur choisi");
						return false;}
				}else {
					js.getcartes_actions().add(carte);
					return true;
				}
			}else {
				System.out.println("vous ne pouvez pas donner cette carte à votre adversaire");
				return false;
			}
		}
	}
}
